//: [Previous](@previous)

import UIKit

let cities = ["New Your", "Berlin", "Paris", "London", "Madrid"]
let selectedCity0 = cities[0] // New York
//let selectedCity10 = cities[10]

extension Collection {
    subscript (safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

let selectedCity3 = cities[safe: 3]
let selectedCity20 = cities[safe: 20]

//: [Next](@next)

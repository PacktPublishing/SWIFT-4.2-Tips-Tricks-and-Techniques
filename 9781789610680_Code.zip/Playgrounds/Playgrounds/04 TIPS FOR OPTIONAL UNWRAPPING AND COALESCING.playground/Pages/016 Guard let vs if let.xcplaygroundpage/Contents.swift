//: [Previous](@previous)

import UIKit

var myUsername: String?
var myPassword: String?

myUsername = "Alex"
myPassword = "123123"

// Ugly Code
func uglyLogIn() {
    if let myUserName = myUsername {
        if let myPassword = myPassword {
//            print("\(myUserName) - \(myPassword)")
        }
    }
}

uglyLogIn()

// Pretty Code
func prettyLogIn() {
    guard let myUsername = myUsername, let myPassword = myPassword else { return }
    print("\(myUsername) - \(myPassword)")
}

prettyLogIn()

//: [Next](@next)

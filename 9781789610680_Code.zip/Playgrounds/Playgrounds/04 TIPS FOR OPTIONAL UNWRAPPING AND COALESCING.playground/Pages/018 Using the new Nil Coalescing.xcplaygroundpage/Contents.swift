//: [Previous](@previous)

import UIKit

var userName: String? = nil
userName = "Alex"

let unwrappedUserName: String = userName ?? "Anonymous"

//: [Next](@next)

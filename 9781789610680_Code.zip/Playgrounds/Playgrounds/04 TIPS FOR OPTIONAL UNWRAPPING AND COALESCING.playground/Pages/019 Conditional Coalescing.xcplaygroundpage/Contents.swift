//: [Previous](@previous)

import UIKit

// initial setup
var currentHeight = 185
var hasSpikyHair = false
var finalHeight = 0

// old way
if hasSpikyHair {
    finalHeight = currentHeight + 5
} else {
    finalHeight = currentHeight
}

// cleaner code
finalHeight = hasSpikyHair ? currentHeight + 5 : currentHeight

//: [Next](@next)

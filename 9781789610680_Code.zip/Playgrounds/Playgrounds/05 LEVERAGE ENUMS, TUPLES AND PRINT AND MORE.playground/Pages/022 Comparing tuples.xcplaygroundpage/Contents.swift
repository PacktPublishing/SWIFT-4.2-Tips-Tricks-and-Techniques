//: [Previous](@previous)

import UIKit

// Comparison cares only about types and ignores labels 😦. So result can be unexpected. Be careful ⚠️.

let car = (model: "Tesla", producer: "USA")
let company = (name: "Tesla", country: "USA")

if car == company {
    print("Equal")
} else {
    print("Not equal")
}

//: [Next](@next)

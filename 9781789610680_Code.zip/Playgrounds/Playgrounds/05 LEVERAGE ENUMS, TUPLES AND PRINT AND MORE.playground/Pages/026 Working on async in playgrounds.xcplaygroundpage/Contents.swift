//: [Previous](@previous)

import Foundation

DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
    print("It's printed in 3 seconds")
}

//: [Next](@next)

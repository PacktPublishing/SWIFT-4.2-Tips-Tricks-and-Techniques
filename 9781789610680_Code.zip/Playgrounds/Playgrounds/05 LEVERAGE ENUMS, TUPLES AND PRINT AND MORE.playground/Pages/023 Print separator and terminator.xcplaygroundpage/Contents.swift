//: [Previous](@previous)

import UIKit

// We know print() as a variadic function. Function that accepts any number of parameters
print("one", "two", "three", "four", "five")

// But it's variadic nature becomes much more useful when you use separator and terminator, its optional extra parameters. separator gives you opportunity to provide a string that should be placed between every item. It's "space" by default
print("one", "two", "three", "four", "five", separator: "-")

// Meanwhile terminator is what should be placed after the last item. It’s \n by default, which means "line break"
print("one", "two", "three", "four", "five", terminator: " six")

//: [Next](@next)

//: [Previous](@previous)

import UIKit

// It’s a good idea to avoid “default” cases when switching on Swift enums - it’ll “force you” to update your logic when a new case is added

enum State {
    case loggedIn
    case loggedOut
    case onboarding
}

func evaluateState(_ state: State) {
    switch state {
    case .loggedIn:
        print("Logged in")
    case .loggedOut:
        print("Logged out")
    case .onboarding:
        print("Onboarding")
    }
}

evaluateState(.onboarding)

//: [Next](@next)

//: [Previous](@previous)

import UIKit

// initial array
let array = [7, 3, 9, 1, 4, 6, 2]

// sorting
var sorted = array.sorted(by: <)

//: [Next](@next)

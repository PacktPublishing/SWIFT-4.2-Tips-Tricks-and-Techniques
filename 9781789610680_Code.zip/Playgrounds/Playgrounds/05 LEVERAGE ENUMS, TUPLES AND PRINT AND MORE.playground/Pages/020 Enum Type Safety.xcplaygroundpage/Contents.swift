//: [Previous](@previous)

import UIKit

// old and unsafe way
//var stringPerson = "Child"
//
//switch stringPerson {
//case "Child":
//    print("Pay $3")
//case "Adult":
//    print("Pay $7")
//case "Senior":
//    print("Pay $4")
//default:
//    print("No such person")
//}

// new and safe way with enums
enum Person {
    case child, adult, senior
}

let person = Person.adult

switch person {
case .child:
    print("Pay $3")
case .adult:
    print("Pay $7")
case .senior:
    print("Pay $4")
}

//: [Next](@next)

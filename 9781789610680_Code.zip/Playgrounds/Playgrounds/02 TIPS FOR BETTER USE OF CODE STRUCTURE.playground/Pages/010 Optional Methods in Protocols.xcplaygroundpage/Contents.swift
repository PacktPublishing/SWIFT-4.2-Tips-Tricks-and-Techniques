//: [Previous](@previous)

import UIKit

// in Swift you must implement all its requirements. Optional methods are not allowed

protocol CarDelegate {
    func engineDidStart()
    func carShouldStartMoving() -> Bool
    func carDidStartMoving()
    func engineWillStop()
    func engineDidStop()
}

// split them in two protocols, and adopt only needed one

protocol CarMovingDelegate {
    func carShouldStartMoving() -> Bool
    func carDidStartMoving()
}

protocol CarEngineDelegate {
    func engineDidStart()
    func engineWillStop()
    func engineDidStop()
}

// Use the @objc attribute on a Swift protocol to receive opportunity to mark methods as being optional

@objc protocol ObjCCarDelegate {
    func engineDidStart()
    @objc func carShouldStartMoving() -> Bool
    @objc func carDidStartMoving()
    func engineWillStop()
    func engineDidStop()
}

// delegate?.engineWillStop?()

// use extensions

protocol NewCarEngineStatusDelegate {
    func engineWillStop()
    func engineDidStop()
}

extension NewCarEngineStatusDelegate {
    func engineWillStop() {}
}

//: [Next](@next)

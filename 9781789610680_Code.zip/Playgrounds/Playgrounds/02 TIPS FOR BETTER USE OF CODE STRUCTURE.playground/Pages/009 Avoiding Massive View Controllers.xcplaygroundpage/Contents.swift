//: [Previous](@previous)

import UIKit

// Before

class SignUpViewController: UIViewController {
    private lazy var signUpLabel = UILabel()
    private lazy var signUpImageView = UIImageView()
    private lazy var signUpButton = UIButton()
}

// After

class BetterSignUpViewController: UIViewController {
    private lazy var signUpView = SignUpView()
}

// preferably in a new file
class SignUpView: UIView {
    private lazy var signUpLabel = UILabel()
    private lazy var signUpImageView = UIImageView()
    private lazy var signUpButton = UIButton()
}

//: [Next](@next)

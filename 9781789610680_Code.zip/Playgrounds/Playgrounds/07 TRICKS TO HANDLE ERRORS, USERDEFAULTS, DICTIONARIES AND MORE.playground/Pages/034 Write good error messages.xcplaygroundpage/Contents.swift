//: [Previous](@previous)

// 1. Say what happened and why
// 2. Suggest a next step
// 3. Find the right tone (If it’s a stressful or serious issue, then a silly tone would be inappropriate)

//: [Next](@next)

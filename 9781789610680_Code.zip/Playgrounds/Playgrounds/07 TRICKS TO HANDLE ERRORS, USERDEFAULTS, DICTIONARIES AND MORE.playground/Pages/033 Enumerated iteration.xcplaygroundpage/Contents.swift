//: [Previous](@previous)

import Foundation

// Use enumerated when you iterate over the collection to return a sequence of pairs (n, c), where n - index for each element and c - its value

let packt = "Packt"

for (c, s) in packt.enumerated() {
    print("\(c) - \(s)")
}

//: [Next](@next)

//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

extension String {
    var words: [String] {
        return components(separatedBy: .punctuationCharacters)
            .joined()
            .components(separatedBy: .whitespaces)
            .filter{!$0.isEmpty}
    }
}

str.words

//: [Next](@next)

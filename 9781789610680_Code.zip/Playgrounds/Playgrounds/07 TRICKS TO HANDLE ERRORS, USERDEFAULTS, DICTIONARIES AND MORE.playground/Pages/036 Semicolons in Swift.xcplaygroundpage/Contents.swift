//: [Previous](@previous)

import Foundation

// Do you need semicolons in Swift? Short answer is NO, but you can use them and it will give you an interesting opportunity. Semicolons enable you to join related components into a single line

func sum(a: Int, b: Int) -> Int {
    let sum = a + b; return sum
}


//: [Next](@next)

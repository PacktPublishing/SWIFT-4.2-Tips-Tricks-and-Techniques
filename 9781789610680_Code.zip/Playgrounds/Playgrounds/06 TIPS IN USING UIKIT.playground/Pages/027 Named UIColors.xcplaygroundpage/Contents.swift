//: [Previous](@previous)

import UIKit

let color = #colorLiteral(red: 0.9921568627, green: 0.7960784314, blue: 0.431372549, alpha: 1)

//: [Next](@next)

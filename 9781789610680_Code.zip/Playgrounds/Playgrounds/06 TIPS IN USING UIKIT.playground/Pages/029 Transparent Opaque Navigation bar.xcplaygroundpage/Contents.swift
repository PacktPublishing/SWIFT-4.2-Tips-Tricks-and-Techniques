//: [Previous](@previous)

import UIKit
import PlaygroundSupport

class TestViewController: UIViewController {
    
    var navBar = UINavigationBar()
    
    func transparentNavigationBar() {
        navBar.setBackgroundImage(UIImage(), for: .default)
        navBar.shadowImage = UIImage()
    }
    
    func opaqueNavigationBar() {
        navBar.setBackgroundImage(nil, for: .default)
        navBar.shadowImage = nil
    }
}


//: [Next](@next)

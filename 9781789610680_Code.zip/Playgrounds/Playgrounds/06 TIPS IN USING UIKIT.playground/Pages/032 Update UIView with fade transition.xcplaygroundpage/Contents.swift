//: [Previous](@previous)

import UIKit

//Really lightweight way 🎈 How to add content changing animation to UIView and it subclasses
extension UIView {
    func fadeTransition(_ duration: CFTimeInterval) {
        let animation = CATransition()
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        animation.duration = duration
        animation.type = .fade
        layer.add(animation, forKey: CATransitionType.fade.rawValue)
    }
}

//: [Next](@next)

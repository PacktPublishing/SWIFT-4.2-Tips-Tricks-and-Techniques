//: [Previous](@previous)

import UIKit

// starter arrays
let intArray: Array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
let stringArray: Array = ["Dan", "Evelin", "Alex", "George"]

// get next element in array extension
extension Array where Element: Hashable {
    func after(_ element: Element) -> Element? {
        if let index = self.index(of: element), index < self.count - 1 {
            return self[index + 1]
        }
        return nil
    }
}

// examples
intArray.after(15)
stringArray.after("Alex")
stringArray.after("Alice")
stringArray.after("George")

//: [Next](@next)

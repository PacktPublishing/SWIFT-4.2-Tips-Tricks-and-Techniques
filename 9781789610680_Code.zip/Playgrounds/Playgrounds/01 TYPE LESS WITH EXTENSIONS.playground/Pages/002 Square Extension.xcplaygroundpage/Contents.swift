//: [Previous](@previous)

import UIKit

// the traditional way of creating a square function
func square(_ value: Int) -> Int { return value * value }

square(5)
square(square(5))

// a smart extension
extension Int {
    var squared: Int { return self * self }
}

// the new and easier way of calling squared
5.squared
5.squared.squared
5.squared.squared.squared

//: [Next](@next)

//: [Previous](@previous)

import UIKit

// the traditional way of creating a color
let blueColor = UIColor.blue

// let's create a color by their RGBA elements; 0.0, 114.0, 188.0
let rebeloperBlue = UIColor(red: 0.0/255.0, green: 114.0/255.0, blue: 188.0/255.0, alpha: 1.0)

// the UIColor extension
extension UIColor {
    convenience public init(r: CGFloat, g: CGFloat, b: CGFloat) {
        self.init(r: r, g: g, b: b, a: 1)
    }
    
    convenience public init(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat) {
        self.init(red: r/255, green: g/255, blue: b/255, alpha: a)
    }
}

// a more convenient way of creating a color
let newRebeloperBlue = UIColor(r: 0, g: 114, b: 188, a: 1)
let theNewestRebeloperBlue = UIColor(r: 0, g: 114, b: 188)

//: [Next](@next)

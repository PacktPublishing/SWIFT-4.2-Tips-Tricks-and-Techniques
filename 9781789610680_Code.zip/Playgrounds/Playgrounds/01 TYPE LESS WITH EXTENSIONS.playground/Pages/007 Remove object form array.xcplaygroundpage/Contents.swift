//: [Previous](@previous)

import UIKit

// starter array
var intArray: Array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

intArray.remove(at: 1)

intArray

// remove element from array
extension Array where Element: Equatable {
    mutating func removeObject(_ object: Element) {
        if let index = index(of: object) {
            self.remove(at: index)
        }
    }
}

intArray.removeObject(10)

intArray

//: [Next](@next)

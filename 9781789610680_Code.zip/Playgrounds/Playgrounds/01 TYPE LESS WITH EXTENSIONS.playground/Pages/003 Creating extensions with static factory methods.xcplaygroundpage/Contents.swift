//: [Previous](@previous)

import UIKit

// creating the static factory methods
extension UILabel {
    static func makeTitleLabel() -> UILabel {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 26)
        label.textColor = .black
        return label
    }
    
    static func makeDescriptionLabel() -> UILabel {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .gray
        return label
    }
}

// calling them in a class
class ViewController: UIViewController {
    let titleLabel: UILabel = UILabel.makeTitleLabel()
    let descriptionLabel: UILabel = UILabel.makeDescriptionLabel()
}

//: [Next](@next)

//: [Previous](@previous)

import UIKit

// starter arrays
var stringArray = ["Bob", "Bobby", "SangJoon"]
var intArray = [1, 3, 4, 5, 6]
var doubleArray = [1.0, 2.0, 3.0]

// old way of printing all elements for String
func printStringArray(a: [String]) {
    for s in a { print(s) }
}

//printStringArray(a: stringArray)

// old way of printing all elements for Int
func printIntArray(a: [Int]) {
    for i in a { print(i) }
}

//printIntArray(a: intArray)

// old way of printing all elements for Double
func printDoubleArray(a: [Double]) {
    for d in a { print(d) }
}

//printDoubleArray(a: doubleArray)

// much simpler and more versatile with Generics
func printElementArray<T>(a: [T]) {
    for e in a { print(e) }
}
printElementArray(a: stringArray)
printElementArray(a: intArray)
printElementArray(a: doubleArray)

//: [Next](@next)

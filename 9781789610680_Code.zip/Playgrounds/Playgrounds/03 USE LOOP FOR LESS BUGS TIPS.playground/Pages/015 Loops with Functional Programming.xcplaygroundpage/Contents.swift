//: [Previous](@previous)

import UIKit

var newEvens = [Int]()
for i in 1...10 {
    if i % 2 == 0 {
        newEvens.append(i)
    }
}
//print(newEvens)

var evens = Array(1...10).filter {
    $0 % 2 == 0
}
print(evens)

//: [Next](@next)

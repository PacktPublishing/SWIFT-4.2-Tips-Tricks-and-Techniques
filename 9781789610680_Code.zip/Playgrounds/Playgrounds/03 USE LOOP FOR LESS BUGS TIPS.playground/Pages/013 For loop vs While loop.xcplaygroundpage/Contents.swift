//: [Previous](@previous)

import UIKit

// Okay Code
//var i = 0
//while i < 5 {
//    print(i)
//    i += 1
//}

// Better Code
for i in 0..<5 { print(i) }

//: [Next](@next)

//: [Previous](@previous)

import UIKit

// our post
struct Post {
    var isMarked = false
}

// set up posts
var post1 = Post()
var post2 = Post()
var post3 = Post()
post1.isMarked = false
post2.isMarked = false
post3.isMarked = true

// posts array
let posts = [post1, post2, post3]

// archive post
func archive(_ post: Post) {
    print("Archiving post: \(post)")
}

// archive using where
func archiveMarkedPosts() {
    for post in posts where post.isMarked {
        archive(post)
    }
}

archiveMarkedPosts()

//: [Next](@next)
